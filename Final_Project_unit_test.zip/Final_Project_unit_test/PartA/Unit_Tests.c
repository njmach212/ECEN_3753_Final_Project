#include <stdlib.h>
#include "ctest.h"
#include "functions.h"
#include <stdio.h>

// Note: the name in the first parameter slot must match all tests in that group
CTEST_DATA(Fifo_Test) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(Fifo_Test) {
    data->head = NULL;
    push(0, 0, &(data->head));
}

CTEST2(Fifo_Test, test_process1) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(0, data->btn);
    ASSERT_EQUAL(0, data->state);
 }

CTEST2(Fifo_Test, test_process2) {
    data->head = NULL;
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(2, data->btn);
    ASSERT_EQUAL(2, data->state);
 }

CTEST2(Fifo_Test, test_process3) {
    data->head = NULL;
    push(1,1,&(data->head));
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(1, data->btn);
    ASSERT_EQUAL(1, data->state);
 }

CTEST_DATA(Gain_Test) {
    uint32_t test;
    uint32_t gain;
};

CTEST_SETUP(Gain_Test) {
    data->test = 0;
    data->gain = 0;
 }

CTEST2(Gain_Test, test_process4) {
    data->gain = 0;
    data->test = gain_function(0,0, data->gain);
    ASSERT_EQUAL(1, data->test);
 }

CTEST2(Gain_Test, test_process5) {
    data->gain = 1;
    data->test = gain_function(1,0, data->gain);
    ASSERT_EQUAL(0, data->test);
 }

CTEST2(Gain_Test, test_process6) {
    data->gain = 0;
    data->test = gain_function(1,0, data->gain);
    ASSERT_EQUAL(0, data->test);
 }


CTEST_DATA(Movement_Test) {
    uint32_t test;
};

CTEST_SETUP(Movement_Test) {
    data->test = 0;
 }

 CTEST2(Movement_Test, test_process7) {
    data->test = 0;
    data->test = direction_function(0);
    ASSERT_EQUAL(0, data->test);
 }

  CTEST2(Movement_Test, test_process8) {
    data->test = 0;
    data->test = direction_function(1);
    ASSERT_EQUAL(2, data->test);
 }

  CTEST2(Movement_Test, test_process9) {
    data->test = 0;
    data->test = direction_function(2);
    ASSERT_EQUAL(2, data->test);
 }

  CTEST2(Movement_Test, test_process10) {
    data->test = 0;
    data->test = direction_function(3);
    ASSERT_EQUAL(1, data->test);
 }

  CTEST2(Movement_Test, test_process11) {
    data->test = 0;
    data->test = direction_function(4);
    ASSERT_EQUAL(1, data->test);
 }

//Physics tests not Written yet 
CTEST_DATA(Physics_Test) {
    struct Physics physics;
    int gain;
    int Dir;
    int start;
    int end;
};

CTEST_SETUP(Physics_Test) {
    data->physics.Gain = 0;
    data->physics.st = 0;
    data->physics.ed = 0;
    data->physics.delta_t = 0;
    data->physics.Dir = 0;
    data->physics.gravity = 9.8;
    data->physics.mass = 2;
    data->physics.length = 10;
    data->physics.xmin = -64;
    data->physics.xmax = 64;
    data->physics.h_velocity = 0;
    data->physics.v_velocity = 0;
    data->physics.h_acceleration = 0;
    data->physics.v_acceleration = 0;
    data->physics.h_force = 0;
    data->physics.v_force = 0;
    data->physics.hb_force = 0;
    data->physics.vb_force = 0;
    data->physics.hc_force = 0;
    data->physics.vc_force = 0;
    data->physics.h_position = 0;
    data->physics.v_position = 10;
    data->physics.theta = 0;
    data->gain = 0;
    data->Dir = 0;
    data->start = 0;
    data->end = 5;
 }

CTEST2(Physics_Test, test_process12) {
    physics_function(data->gain, &(data->physics), data->Dir, data->start, data->end);
    ASSERT_EQUAL(0, (data->physics.theta)*180/M_PI);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(10, data->physics.v_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(5, data->physics.delta_t*1000);
 }

CTEST2(Physics_Test, test_process13) {
    data->gain = 20;
    data->Dir = 1;
    data->start = 0;
    data->end = 5;
    physics_function(data->gain, &(data->physics), data->Dir, data->start, data->end);
    ASSERT_EQUAL(0, (data->physics.theta)*180/M_PI);
    ASSERT_EQUAL(0, data->physics.h_position);
    ASSERT_EQUAL(10, data->physics.v_position);
    ASSERT_EQUAL(0, (data->physics.hc_position)*100);
    ASSERT_EQUAL(5, (data->physics.delta_t)*1000);
 }

CTEST2(Physics_Test, test_process14) {
    data->gain = 20;
    data->Dir = 1;
    data->start = 0;
    data->end = 1000;
    data->physics.theta = -0.78;
    data->physics.v_position = 7.032;
    data->physics.hc_position = 6.95;
    physics_function(data->gain, &(data->physics), data->Dir, data->start, data->end);
    ASSERT_EQUAL(-1, (data->physics.theta)*180/M_PI);
    ASSERT_EQUAL(30, data->physics.h_position*100);
    ASSERT_EQUAL(7, data->physics.v_position);
    ASSERT_EQUAL(0, data->physics.hc_position);
    ASSERT_EQUAL(1000, (data->physics.delta_t)*1000);
 }

// CTEST2(Physics_Test, test_process15) {
//     data->f = 3;
//     physics_function(data->f, data->physics);
//     ASSERT_EQUAL(86, data->physics.theta);
//     ASSERT_EQUAL(3, data->physics.f);
//  }

// CTEST2(Physics_Test, test_process16) {
//     data->f = 4;
//     physics_function(data->f, data->physics);
//     ASSERT_EQUAL(85, data->physics.theta);
//     ASSERT_EQUAL(4, data->physics.f);
//  }

// CTEST2(Physics_Test, test_process17) {
//     data->f = 5;
//     physics_function(data->f, data->physics);
//     ASSERT_EQUAL(84, data->physics.theta);
//     ASSERT_EQUAL(5, data->physics.f);
//  }

// CTEST2(Physics_Test, test_process18) {
//     data->f = 6;
//     physics_function(data->f, data->physics);
//     ASSERT_EQUAL(76, data->physics.theta);
//     ASSERT_EQUAL(6, data->physics.f);
//  }
