
#ifndef __FIRST_COME_FIRST_SERVED__
#define __FIRST_COME_FIRST_SERVED__

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>

struct node
{
	bool btn;
	bool state;
	struct node *next;
};

struct Physics
{
	double Gain;
	double st;
	double ed;
	double delta_t;
	double Dir;
	double gravity;
	double mass;
	double length;
	int xmin;
	int xmax;
	double theta;
	double h_velocity;
	double v_velocity;
	double h_acceleration;
	double v_acceleration;
	double hb_force;
	double vb_force;
	double hc_force;
	double vc_force;
	double v_force;
	double h_force;
	double h_position;
	double v_position;
	double hc_position;
};

void pop(int *btn, int *state, struct node **head);

void push(int btn, int state, struct node **head);

uint32_t gain_function(int btn, int state, uint32_t gain);

uint32_t direction_function(int sld);

void physics_function(int gain, struct Physics *physics, int Dir, int start, int end);

#endif // __FIRST_COME_FIRST_SERVED__