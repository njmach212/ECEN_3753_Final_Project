#include "functions.h"
#include <stdio.h>


void push(int btn, int state, struct node **head)
{
	if (*head == NULL)
	{
		*head = malloc(sizeof(struct node));
		(*head)->btn = btn;
		(*head)->state = state;
		(*head)->next = NULL;
	}
	else
	{
		struct node *temp;
		temp = *head;
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		struct node * node;
		node = malloc(sizeof(struct node));
		node->btn = btn;
		node->state = state;
		node->next = NULL;
	}
}

void pop(int *btn, int *state, struct node **head)
{
	if (*head == NULL)
	{
		*btn = 2;
		*state = 2;
	}
	else
	{
		struct node *temp;
		temp = *head;
		*head = (*head)->next;
		*btn = temp->btn;
		*state = temp->state;
		free(temp);
	}
}

uint32_t gain_function(int btn, int state, uint32_t gain)
{
    if(btn == 0 && state == 0)
    {
        gain++;
    }
    else if(btn == 1 && state == 0 && gain != 0)
    {
        gain--;
    }
    return gain;
}

uint32_t direction_function(int sld)
{
    uint32_t Direction = 0;
    if (sld == 1)
    {
    	Direction = 2;
    }
    else if (sld == 2)
    {
    	Direction = 2;
    }
    else if (sld == 3)
    {
    	Direction = 1;
    }
    else if (sld == 4)
    {
    	Direction = 1;
    }
    else
    {
    	Direction = 0;
    }
    return Direction;
}

void physics_function(int gain, struct Physics *physics, int Dir, int start, int end)
{
        if(physics->theta >= M_PI/2 || physics->theta <= -M_PI/2 || physics->hc_position <= -64 || physics->hc_position >= 64)
        {
            physics->length = 0;
        }
        physics->Gain = gain;
        physics->Dir = Dir;
		physics->st = start;
        physics->ed = end;
        if(physics->Gain != 0 && physics->theta == 0 && physics->Dir == 1)
        {
            physics->theta = -0.0175;
        }
        else if (physics->Gain != 0 && physics->theta == 0 && physics->Dir == 2)
        {
            physics->theta = 0.0175;
        }
        physics->delta_t = (physics->ed - physics->st)/1000;
        physics->vb_force = physics->mass * physics->gravity;
        physics->hb_force = -(physics->vb_force * tan(physics->theta));
        physics->hc_force = (physics->Gain * (bool)(physics->Dir))*sin(physics->theta)*sin(physics->theta);
        if(physics->theta == 0)
        {
        	physics->vc_force = physics->mass*physics->gravity;
        }
        else
        {
        	physics->vc_force = (physics->Gain*(bool)(physics->Dir))*sin(physics->theta)*cos(physics->theta);
            if(physics->vc_force < 0)
            {
                physics->vc_force = -physics->vc_force;
            }
        }
        physics->v_force = physics->vc_force - physics->vb_force;
        if(physics->Dir == 1)
        {
            if(physics->hb_force < physics->hc_force)
            {
                physics->h_force = physics->hb_force + physics->hc_force;
            }
            else
            {
                physics->h_force = 0;
            }
        }
        else if(physics->Dir == 2)
        {
            if(physics->hb_force < physics->hc_force)
            {
                physics->h_force = physics->hb_force - physics->hc_force;
            }
            else
            {
                physics->h_force = 0;
            }
        }
        else
        {
            physics->h_force = 0;
        }
        physics->v_acceleration = physics->v_force/physics->mass;
        physics->h_acceleration = physics->h_force/physics->mass;
        physics->v_velocity = physics->v_velocity + physics->v_acceleration*physics->delta_t;
        physics->h_velocity = physics->h_velocity + physics->h_acceleration*physics->delta_t;
        physics->v_position = physics->v_position + physics->v_velocity*physics->delta_t;
        physics->h_position = physics->h_position + physics->h_velocity*physics->delta_t;
        physics->hc_position = -physics->length*sin(physics->theta);
        if(physics->hc_position < physics->h_position)
        {
            physics->theta = acos(physics->v_position/physics->length);
        }
        else if(physics->hc_position > physics->h_position)
        {
            physics->theta = -acos(physics->v_position/physics->length);
        }
        else
        {
            physics->theta = 0;
        }
        physics->st = physics->ed;
}