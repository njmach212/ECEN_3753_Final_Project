#include <stdlib.h>
#include "ctest.h"
#include "functions.h"

// Note: the name in the first parameter slot must match all tests in that group
CTEST_DATA(Fifo_Test) {
    struct node *head;
    int state;
    int btn;
};

CTEST_SETUP(Fifo_Test) {
    data->head = NULL;
    push(0, 0, &(data->head));
}

CTEST2(Fifo_Test, test_process1) {
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(0, data->btn);
    ASSERT_EQUAL(0, data->state);
 }

CTEST2(Fifo_Test, test_process2) {
    data->head = NULL;
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(2, data->btn);
    ASSERT_EQUAL(2, data->state);
 }

CTEST2(Fifo_Test, test_process3) {
    data->head = NULL;
    push(1,1,&(data->head));
    pop(&(data->btn), &(data->state), &(data->head));
    ASSERT_EQUAL(1, data->btn);
    ASSERT_EQUAL(1, data->state);
 }

CTEST_DATA(Gain_Test) {
    uint32_t test;
    uint32_t gain;
};

CTEST_SETUP(Gain_Test) {
    data->test = 0;
    data->gain = 0;
 }

CTEST2(Gain_Test, test_process4) {
    data->gain = 0;
    data->test = gain_function(0,0, data->gain);
    ASSERT_EQUAL(1, data->test);
 }

CTEST2(Gain_Test, test_process5) {
    data->gain = 1;
    data->test = gain_function(1,0, data->gain);
    ASSERT_EQUAL(0, data->test);
 }

CTEST2(Gain_Test, test_process6) {
    data->gain = 0;
    data->test = gain_function(1,0, data->gain);
    ASSERT_EQUAL(0, data->test);
 }


CTEST_DATA(Movement_Test) {
    uint32_t test;
};

CTEST_SETUP(Movement_Test) {
    data->test = 0;
 }

 CTEST2(Movement_Test, test_process7) {
    data->test = 0;
    data->test = direction_function(0);
    ASSERT_EQUAL(0, data->test);
 }

  CTEST2(Movement_Test, test_process8) {
    data->test = 0;
    data->test = direction_function(1);
    ASSERT_EQUAL(2, data->test);
 }

  CTEST2(Movement_Test, test_process9) {
    data->test = 0;
    data->test = direction_function(2);
    ASSERT_EQUAL(2, data->test);
 }

  CTEST2(Movement_Test, test_process10) {
    data->test = 0;
    data->test = direction_function(3);
    ASSERT_EQUAL(1, data->test);
 }

  CTEST2(Movement_Test, test_process11) {
    data->test = 0;
    data->test = direction_function(4);
    ASSERT_EQUAL(1, data->test);
 }

//Physics tests not Written yet 
CTEST_DATA(Physics_Test) {
    struct Physics physics;
    int f;

CTEST_SETUP(Physics_Test) {
    data->f = 0;
 }

CTEST2(Physics_Test, test_process12) {
    data->f = 2;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(88, data->physics.theta);
    ASSERT_EQUAL(2, data->physics.f);
 }

CTEST2(Physics_Test, test_process13) {
    data->f = 0;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(90, data->physics.theta);
    ASSERT_EQUAL(0, data->physics.f);
 }

CTEST2(Physics_Test, test_process14) {
    data->f = 1;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(89, data->physics.theta);
    ASSERT_EQUAL(1, data->physics.f);
 }

CTEST2(Physics_Test, test_process15) {
    data->f = 3;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(86, data->physics.theta);
    ASSERT_EQUAL(3, data->physics.f);
 }

CTEST2(Physics_Test, test_process16) {
    data->f = 4;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(85, data->physics.theta);
    ASSERT_EQUAL(4, data->physics.f);
 }

CTEST2(Physics_Test, test_process17) {
    data->f = 5;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(84, data->physics.theta);
    ASSERT_EQUAL(5, data->physics.f);
 }

CTEST2(Physics_Test, test_process18) {
    data->f = 6;
    physics_function(data->f, data->physics);
    ASSERT_EQUAL(76, data->physics.theta);
    ASSERT_EQUAL(6, data->physics.f);
 }
