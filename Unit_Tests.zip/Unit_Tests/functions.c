#include "functions.h"
#include "queue.h"
#include <stdio.h>


void push(int btn, int state, struct node **head)
{
	if (*head == NULL)
	{
		*head = malloc(sizeof(struct node));
		(*head)->btn = btn;
		(*head)->state = state;
		(*head)->next = NULL;
	}
	else
	{
		struct node *temp;
		temp = *head;
		while(temp->next != NULL)
		{
			temp = temp->next;
		}
		struct node * node;
		node = malloc(sizeof(struct node));
		node->btn = btn;
		node->state = state;
		node->next = NULL;
	}
}

void pop(int *btn, int *state, struct node **head)
{
	if (*head == NULL)
	{
		*btn = 2;
		*state = 2;
	}
	else
	{
		struct node *temp;
		temp = *head;
		*head = (*head)->next;
		*btn = temp->btn;
		*state = temp->state;
		free(temp);
	}
}

uint32_t gain_function(int btn, int state, uint32_t gain)
{
    if(btn == 0 && state == 0)
    {
        gain++;
    }
    else if(btn == 1 && state == 0 && gain != 0)
    {
        gain--;
    }
    return gain;
}

uint32_t direction_function(int sld)
{
    uint32_t Direction = 0;
    if (sld == 1)
    {
    	Direction = 2;
    }
    else if (sld == 2)
    {
    	Direction = 2;
    }
    else if (sld == 3)
    {
    	Direction = 1;
    }
    else if (sld == 4)
    {
    	Direction = 1;
    }
    else
    {
    	Direction = 0;
    }
    return Direction;
}

void physics_function(intf, struct Physics physics)
{
    //todo
}