
#ifndef __FIRST_COME_FIRST_SERVED__
#define __FIRST_COME_FIRST_SERVED__

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

struct node
{
	bool btn;
	bool state;
	struct node *next;
};

struct Physics
{
    int f;
    int v;
    int a;
    int xcart;
    int xball;
    int theta;
}

void pop(int *btn, int *state, struct node **head);

void push(int btn, int state, struct node **head);

uint32_t gain_function(int btn, int state, uint32_t gain);

uint32_t direction_function(int sld);

void physics_function(intf, struct Physics physics);

#endif // __FIRST_COME_FIRST_SERVED__